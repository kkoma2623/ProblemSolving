console.warn("Cloudinary's Upload Widget 1.0 is no longer available. See: https://cloudinary.com/documentation/upload_widget for info about our latest Upload Widget.")

